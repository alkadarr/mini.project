package com.Movies.dtos.reviewer;

import lombok.Data;

@Data
public class CompleteProfileDto {

    private String firstName;
    private String lastName;

}
