package com.Movies.services.abstraction;

public interface ActorService {
    // custom methods
}
