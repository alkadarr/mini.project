package com.Movies.services.abstraction;

public interface DirectorService {
    // custom methods
}
