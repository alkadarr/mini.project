package com.Movies.services.abstraction;

public interface GenreService {
    // custom methods
}
